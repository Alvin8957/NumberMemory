﻿
namespace NumberMemory
{
    partial class NumberMemory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblNumber = new System.Windows.Forms.Label();
            this.btnStarten = new System.Windows.Forms.Button();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.txtEingabe = new System.Windows.Forms.TextBox();
            this.btnBestätigen = new System.Windows.Forms.Button();
            this.lblAnleitung = new System.Windows.Forms.Label();
            this.lblLevelAnzeige = new System.Windows.Forms.Label();
            this.lblLevel = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblSpieler = new System.Windows.Forms.Label();
            this.lblSpielerAnzeige = new System.Windows.Forms.Label();
            this.lblEingabeAnzeige = new System.Windows.Forms.Label();
            this.lblAnleitungAnzeige = new System.Windows.Forms.Label();
            this.lblTitel = new System.Windows.Forms.Label();
            this.lblZahlAnzeige = new System.Windows.Forms.Label();
            this.lblTimerAnzeige = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNumber
            // 
            this.lblNumber.AutoSize = true;
            this.lblNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumber.Location = new System.Drawing.Point(172, 145);
            this.lblNumber.Name = "lblNumber";
            this.lblNumber.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblNumber.Size = new System.Drawing.Size(36, 51);
            this.lblNumber.TabIndex = 0;
            this.lblNumber.Text = "-";
            this.lblNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnStarten
            // 
            this.btnStarten.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStarten.Location = new System.Drawing.Point(181, 404);
            this.btnStarten.Name = "btnStarten";
            this.btnStarten.Size = new System.Drawing.Size(344, 72);
            this.btnStarten.TabIndex = 2;
            this.btnStarten.Text = "STARTEN";
            this.btnStarten.UseVisualStyleBackColor = true;
            this.btnStarten.Click += new System.EventHandler(this.btnStarten_Click);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(181, 351);
            this.progressBar1.MarqueeAnimationSpeed = 1000;
            this.progressBar1.Maximum = 8;
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(709, 23);
            this.progressBar1.TabIndex = 1;
            this.progressBar1.Visible = false;
            // 
            // txtEingabe
            // 
            this.txtEingabe.Enabled = false;
            this.txtEingabe.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEingabe.Location = new System.Drawing.Point(181, 240);
            this.txtEingabe.Name = "txtEingabe";
            this.txtEingabe.Size = new System.Drawing.Size(709, 56);
            this.txtEingabe.TabIndex = 4;
            this.txtEingabe.Visible = false;
            this.txtEingabe.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEingabe_KeyPress);
            // 
            // btnBestätigen
            // 
            this.btnBestätigen.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBestätigen.Location = new System.Drawing.Point(546, 404);
            this.btnBestätigen.Name = "btnBestätigen";
            this.btnBestätigen.Size = new System.Drawing.Size(344, 72);
            this.btnBestätigen.TabIndex = 5;
            this.btnBestätigen.Text = "BESTÄTIGEN";
            this.btnBestätigen.UseVisualStyleBackColor = true;
            this.btnBestätigen.Click += new System.EventHandler(this.btnBestätigen_Click);
            // 
            // lblAnleitung
            // 
            this.lblAnleitung.AutoSize = true;
            this.lblAnleitung.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnleitung.Location = new System.Drawing.Point(178, 80);
            this.lblAnleitung.Name = "lblAnleitung";
            this.lblAnleitung.Size = new System.Drawing.Size(551, 37);
            this.lblAnleitung.TabIndex = 6;
            this.lblAnleitung.Text = "Klicke auf STARTEN um zu beginnen";
            this.lblAnleitung.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLevelAnzeige
            // 
            this.lblLevelAnzeige.AutoSize = true;
            this.lblLevelAnzeige.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLevelAnzeige.Location = new System.Drawing.Point(539, 504);
            this.lblLevelAnzeige.Name = "lblLevelAnzeige";
            this.lblLevelAnzeige.Size = new System.Drawing.Size(100, 37);
            this.lblLevelAnzeige.TabIndex = 7;
            this.lblLevelAnzeige.Text = "Level:";
            // 
            // lblLevel
            // 
            this.lblLevel.AutoSize = true;
            this.lblLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLevel.Location = new System.Drawing.Point(645, 504);
            this.lblLevel.Name = "lblLevel";
            this.lblLevel.Size = new System.Drawing.Size(27, 37);
            this.lblLevel.TabIndex = 8;
            this.lblLevel.Text = "-";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblSpieler
            // 
            this.lblSpieler.AutoSize = true;
            this.lblSpieler.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSpieler.Location = new System.Drawing.Point(142, 501);
            this.lblSpieler.Name = "lblSpieler";
            this.lblSpieler.Size = new System.Drawing.Size(27, 37);
            this.lblSpieler.TabIndex = 9;
            this.lblSpieler.Text = "-";
            // 
            // lblSpielerAnzeige
            // 
            this.lblSpielerAnzeige.AutoSize = true;
            this.lblSpielerAnzeige.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSpielerAnzeige.Location = new System.Drawing.Point(12, 501);
            this.lblSpielerAnzeige.Name = "lblSpielerAnzeige";
            this.lblSpielerAnzeige.Size = new System.Drawing.Size(124, 37);
            this.lblSpielerAnzeige.TabIndex = 10;
            this.lblSpielerAnzeige.Text = "Spieler:";
            // 
            // lblEingabeAnzeige
            // 
            this.lblEingabeAnzeige.AutoSize = true;
            this.lblEingabeAnzeige.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEingabeAnzeige.Location = new System.Drawing.Point(4, 246);
            this.lblEingabeAnzeige.Name = "lblEingabeAnzeige";
            this.lblEingabeAnzeige.Size = new System.Drawing.Size(152, 37);
            this.lblEingabeAnzeige.TabIndex = 11;
            this.lblEingabeAnzeige.Text = "Eingabe: ";
            this.lblEingabeAnzeige.Visible = false;
            // 
            // lblAnleitungAnzeige
            // 
            this.lblAnleitungAnzeige.AutoSize = true;
            this.lblAnleitungAnzeige.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnleitungAnzeige.Location = new System.Drawing.Point(4, 80);
            this.lblAnleitungAnzeige.Name = "lblAnleitungAnzeige";
            this.lblAnleitungAnzeige.Size = new System.Drawing.Size(160, 37);
            this.lblAnleitungAnzeige.TabIndex = 12;
            this.lblAnleitungAnzeige.Text = "Anleitung:";
            // 
            // lblTitel
            // 
            this.lblTitel.AutoSize = true;
            this.lblTitel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitel.Location = new System.Drawing.Point(325, 19);
            this.lblTitel.Name = "lblTitel";
            this.lblTitel.Size = new System.Drawing.Size(352, 37);
            this.lblTitel.TabIndex = 1;
            this.lblTitel.Text = "MERKE DIR DIE ZAHL!";
            this.lblTitel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblZahlAnzeige
            // 
            this.lblZahlAnzeige.AutoSize = true;
            this.lblZahlAnzeige.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblZahlAnzeige.Location = new System.Drawing.Point(4, 157);
            this.lblZahlAnzeige.Name = "lblZahlAnzeige";
            this.lblZahlAnzeige.Size = new System.Drawing.Size(98, 37);
            this.lblZahlAnzeige.TabIndex = 13;
            this.lblZahlAnzeige.Text = "Zahl: ";
            // 
            // lblTimerAnzeige
            // 
            this.lblTimerAnzeige.AutoSize = true;
            this.lblTimerAnzeige.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimerAnzeige.Location = new System.Drawing.Point(4, 337);
            this.lblTimerAnzeige.Name = "lblTimerAnzeige";
            this.lblTimerAnzeige.Size = new System.Drawing.Size(108, 37);
            this.lblTimerAnzeige.TabIndex = 14;
            this.lblTimerAnzeige.Text = "Timer:";
            // 
            // NumberMemory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(945, 550);
            this.Controls.Add(this.lblTimerAnzeige);
            this.Controls.Add(this.lblZahlAnzeige);
            this.Controls.Add(this.lblAnleitungAnzeige);
            this.Controls.Add(this.lblEingabeAnzeige);
            this.Controls.Add(this.lblSpielerAnzeige);
            this.Controls.Add(this.lblSpieler);
            this.Controls.Add(this.lblLevel);
            this.Controls.Add(this.lblLevelAnzeige);
            this.Controls.Add(this.lblAnleitung);
            this.Controls.Add(this.btnBestätigen);
            this.Controls.Add(this.txtEingabe);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.btnStarten);
            this.Controls.Add(this.lblTitel);
            this.Controls.Add(this.lblNumber);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "NumberMemory";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Number Memory";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumber;
        private System.Windows.Forms.Button btnStarten;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.TextBox txtEingabe;
        private System.Windows.Forms.Button btnBestätigen;
        private System.Windows.Forms.Label lblAnleitung;
        private System.Windows.Forms.Label lblLevelAnzeige;
        private System.Windows.Forms.Label lblLevel;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblSpieler;
        private System.Windows.Forms.Label lblSpielerAnzeige;
        private System.Windows.Forms.Label lblEingabeAnzeige;
        private System.Windows.Forms.Label lblAnleitungAnzeige;
        private System.Windows.Forms.Label lblTitel;
        private System.Windows.Forms.Label lblZahlAnzeige;
        private System.Windows.Forms.Label lblTimerAnzeige;
    }
}