﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NumberMemory
{
    public partial class Start : Form
    {
        public Start()
        {
            InitializeComponent();
        }

        public static string Spielername = "Spieler";

        private void btnStart_Click(object sender, EventArgs e)
        {
            this.Hide();
            Spielername = txtSpielername.Text;
            NumberMemory Anzeigen = new NumberMemory();
            Anzeigen.ShowDialog();
            this.Close();
        }

        private void txtSpielername_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Return)
            {
                btnStart_Click(sender, e);
            }
        }

        
    }
}
