﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// --------------------------------------------
// Datei:			NumberMemory
// Datum:			19.02.2021
// Ersteller:		Alvin Van Tran
// Beschreibung:    
// -- Number Memory Game
// --------------------------------------------

namespace NumberMemory
{
    public partial class NumberMemory : Form
    {
        public NumberMemory()
        {
            InitializeComponent();
            btnBestätigen.Hide();
            lblSpieler.Text = Start.Spielername;

        }

        int eineZifferAddieren = 10;
        int eineZifferAddieren2 = 1;
        private int level;







        //Nach STARTButton, eine zufällige Zahl generieren && alles verstecken
        private void btnStarten_Click(object sender, EventArgs e)
        {
            lblNumber.Text = "";
            btnStarten.Hide();
            lblAnleitung.Hide();
            lblTimerAnzeige.Show();
            lblAnleitungAnzeige.Hide();

            progressBar1.Show();
            timer1.Start();
            progressBar1.Value = 0;

            level++;
            lblLevel.Text = level.ToString();


            Random rnd = new Random();
            decimal rndZahl = rnd.Next(eineZifferAddieren / 10, eineZifferAddieren);
            string rndstring = rndZahl.ToString();


            if (level <= 8)
            {
                eineZifferAddieren = eineZifferAddieren * 10;

            }
            else if (level >= 10)
            {
                eineZifferAddieren2 = eineZifferAddieren2 * 10;
                decimal rndZahl2 = rnd.Next(eineZifferAddieren2 / 10, eineZifferAddieren2);
                string rndString2 = rndZahl2.ToString();
                lblNumber.Text += rndString2;
            }
            lblNumber.Text += rndstring;
        }


        //Mach das alles nach der erreichten Zeit
        private void timer1_Tick(object sender, EventArgs e)
        {


            if (progressBar1.Value != 8)
            {
                progressBar1.Value++;
            }
            else if (progressBar1.Value == 8)
            {
                timer1.Stop();
                progressBar1.Hide();
                lblNumber.Hide();
                btnStarten.Hide();
                lblEingabeAnzeige.Show();
                lblAnleitungAnzeige.Hide();
                lblAnleitung.Show();
                lblZahlAnzeige.Hide();
                lblAnleitungAnzeige.Show();
                lblTimerAnzeige.Hide();
                btnBestätigen.Show();

                txtEingabe.Enabled = true;
                txtEingabe.Visible = true;


                lblTitel.Text = "Was war die Zahl?";
                lblAnleitung.Text = "--Gib die Zahl ein und Klicke auf BESTÄTIGEN--";
            }
            else
            {
                timer1.Enabled = false;
            }
        }



        //bestätigen Knopf, vergleichen ob Zahl und Eingabe glech sind.
        private void btnBestätigen_Click(object sender, EventArgs e)
        {
            try
            {
                decimal richtigeZahl = Convert.ToDecimal(lblNumber.Text);
                decimal eingegebeneZahl = Convert.ToDecimal(txtEingabe.Text);

                if (richtigeZahl == eingegebeneZahl && level == 17)
                {
                    MessageBox.Show("GLÜCKWUNSCH \n" +
                        "DU BIST EIN FIVEHEAD\n" +
                        "HIER GIBT ES NICHTS MEHR, BYE!");
                    this.Close();
                }
                else if (richtigeZahl == eingegebeneZahl)
                {
                    MessageBox.Show("Richtig, gut gemacht!");

                    lblNumber.Show();
                    lblAnleitungAnzeige.Show();
                    lblZahlAnzeige.Show();
                    lblTimerAnzeige.Show();
                    lblEingabeAnzeige.Hide();
                    lblTimerAnzeige.Show();
                    lblNumber.Text = "-";
                    lblTitel.Text = "MERKE DIR DIE ZAHL!";
                    lblAnleitung.Text = "--Klicke auf START um zu beginnen--";

                    btnBestätigen.Hide();
                    btnStarten.Show();

                    txtEingabe.Clear();
                    txtEingabe.Hide();
                }
                else
                {
                    MessageBox.Show($"FALSCH\n" +
                        $"Level: {level}\n" +
                        $"Die Zahl war: {richtigeZahl.ToString()}\n" +
                        $"Deine Antwort: {eingegebeneZahl}\n" +
                        $"Viel Glück beim nächsten Mal! :p");
                    this.Close();
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Bitte gib eine gültige Zahl ein");
            }
        }



        //(Aus dem Internet) Nur Zahlen eingeben können
        private void txtEingabe_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
            if (e.KeyChar == (char)Keys.Return)
            {
                btnBestätigen_Click(sender, e);
            }
        }

    }
}